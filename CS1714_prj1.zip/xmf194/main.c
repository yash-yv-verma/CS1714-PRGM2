#include "dicegame.h" //This header allows the dicegame function to work in main function
#include <stdio.h> //Standard input & output
#include <stdlib.h> // Includes the standard library
#include <time.h> // This gets time since 1970 Jan. 1st


int main(int argc, char *argv[]) {

  srand((int)time( 0 )); // srand() to set the seed for random

  // Declaration of all necessary variables.
  int numRounds;
  int diceRoll;
  int points;
  int i;
  int currentPlayer;
  int p1Points;
  int p2Points;

  //Initialization of all variables to 0
   numRounds = 0;
   diceRoll = 0;
   points = 0;
   i = 0;
   currentPlayer = 0;
   p1Points = 0;
   p2Points = 0;
  

  // Ask the user for the number of rounds to run the game
  printf("Enter the number of rounds: ");
  scanf("%d", &numRounds);

  printPlayerPoints(p1Points, p2Points); // To print the initial player points
  currentPlayer = getRandomNumber(1, 2); // This is the first dice roll

  for (i = 1; i <= numRounds; i++) { // This loop runs based on the user defined numRounds

    diceRoll = getRandomNumber(1, 6);  // This is dice roll
    enum ROUNDTYPE t = getRoundType(); // This gets that round type based on the random number and also distribution
    points = getRoundPoints(t); // This gives points based on the distribution

    printf("\nROUND %d\n", i); // Prints round #
    printf("--------\n");

    printf("Player  : %d", currentPlayer);//Prints the current player

    printRoundInfo(t, diceRoll, points);//This method call prints Round info

    // MAIN GAME LOGIC

    //This entire branch helps add or subtract points from players and also checks to see if the players need to be switched -->
    if(currentPlayer == 1 && ( diceRoll % 2 != 0) ){
  
      p1Points = p1Points + points;
      currentPlayer = 1;
      
    }else if(currentPlayer == 1 && (diceRoll % 2 == 0 )){

      p1Points = p1Points - points;
      currentPlayer = 2;
      
    }else if(currentPlayer == 2 && ( diceRoll % 2 == 0 )){

      p2Points = p2Points + points;
      currentPlayer = 2;
      
    }else if(currentPlayer == 2 && ( diceRoll % 2 != 0)){

      p2Points = p2Points - points;
      currentPlayer = 1;
      
    }
    
    printPlayerPoints(p1Points, p2Points);//This prints the players current points
  }//End of the loop

  printf("\nGAME OVER!!\n");//This shows the user the game is over

  if (p1Points > p2Points) {//This branch checks if p1 or p2 won
    printf("P1 Won\n");
  } else {
    printf("P2 Won\n");
  }

  return 0;//End of code
}
