#include "dicegame.h"//This includes the header file of dicegame
#include <stdio.h>//Standard input & output
#include <stdlib.h>//Standard Library
#include <time.h>//Time function

int getRandomNumber(int min, int max) {//This function gets a random number from min to max (inclusive)

  int randReturn;
  randReturn = 0;
  randReturn = rand() % ((max - min) + 1) + min;//generates random number

  return randReturn;

}

enum ROUNDTYPE getRoundType() {//This funtion generates a random number and based on the distribution returns the roundtype

  enum ROUNDTYPE roundType;
  int randVal;
  randVal = 0;
  randVal = getRandomNumber(0, 9);//Generates random number
  
  if (randVal <= 4 && randVal >= 0) {//This branch helps the rand. number
    
    roundType = REGULAR;
    
  } else if (randVal >= 5 && randVal <= 7) {
    
    roundType = DOUBLE;
    
  } else if (randVal >= 8 && randVal <= 9) {
    
    roundType = BONUS;
    
  } else {
    
    printf("CODE IS WRONG");
    
  }

  return roundType;
}

int getRoundPoints(enum ROUNDTYPE roundType) {//This function takes in the roundtype as a parameter and generates a random number and returns the point based on the type of round
  int returnPoints;
  returnPoints = 0;

  if (roundType == REGULAR) {
    returnPoints = 10 * (getRandomNumber(1, 10));
  } else if (roundType == DOUBLE) {
    returnPoints = 2 * (10 * (getRandomNumber(1, 10)));
  } else if (roundType == BONUS) {
    returnPoints = 200;
  } else {
    printf("CODE IS WRONG");
  }

  return returnPoints;
}

void printPlayerPoints(int p1Points, int p2Points) {//This function prints p1 and p2 players

  printf("P1\t\t: %d\n", p1Points);
  printf("P2\t\t: %d\n", p2Points);
}

void printRoundInfo(enum ROUNDTYPE t, int dice, int points) {//This function prints the rounds info the round type, dice, and points
  if (t == BONUS) {
    printf("\nType    : BONUS\n");
  } else if (t == REGULAR) {
    printf("\nType    : REGULAR\n");
  } else {
    printf("\nType    : DOUBLE\n");
  }

  printf("DICE    : %d\n", dice);//Prints dice value
  printf("POINTS  : %d\n", points);//Prints points
}