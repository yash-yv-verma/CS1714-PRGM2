#include "champions.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
    if(argc<2){    //checks if user provided aditional arguments for number of champions
    
        printf("Argument not Provided\n");
        return -1;   //if not then ends program
    }

    int num = atoi(argv[1]);                // converts the string to an integer value

    if(num <= 0)                            // checks for if the number is negative
    {
        printf("Number must be greater than 0\n");
        return -1;                                      //if it is then ends program
    }
    srand(time(0));             //seed to use random function
    int round = 1;
    Champion* player1 = buildChampionList(num);             //gives the players number of chhampion
    Champion* player2 = buildChampionList(num);

    Champion* p1copy = player1; //create copy of the players
    Champion* p2copy = player2;

    printf("\n============= PLAYER 1 V PLAYER 2 SHOWDOWN ============\n");
    
    while((player1 != NULL) && (player2 != NULL))                       //loop that runs until one player no longer has champions
    {
	    printf("\n----- ROUND %d -----\n", round);
	    printf("Player 1: ");
	    printChampionList(player1);
	    printf("Player 2: ");
	    printChampionList(player2);

	    char player1Role = p1copy->role;
	    int player1Level = p1copy->level;
	    char player2Role = p2copy->role;
	    int player2Level = p2copy->level;

	    if(player1Role == 'M')          //if player one is mage
	    {
	        if(player2Role == 'M')  //if player 2 is mage
	        {
		        printf("Player 1 is a MAGE and Player 2 is a MAGE\n");
		        if(player1Level > player2Level) // if player1 wins gains champions
		        {
		            player1 = addChampion(player1, createChampion());
		            player2 = removeChampion(player2);
		            printf("Player 1 (MAGE) wins and gains one new champion.\n");
		            printf("Plauer 2(MAGE) loses one champion.\n");
		        }

		        else if(player2Level > player1Level)    //if player2 wins gains champion
		        {
		            player2 = addChampion(player2, createChampion());
		            player1 = removeChampion(player1);
		            printf("Player 1 (MAGE) loses and one champion.\n");
		            printf("Player 2 (MAGE) wins and gains one new champion.\n");
		        }

		        else if(player1Level == player2Level)   //tie nothing happens
		        {
		            printf("TIE.\n");
		        }
	        }

	        else if(player2Role == 'F') // if player 2 is a FIGHTER
	        {
		        printf("Player 1 is a MAGE and Player 2 is a FIGHTER\n");
		        if(player1Level > player2Level)     //if player1 wins gains champion
		        {
		            player1 = addChampion(player1, createChampion());
		            printf("Player 1 (MAGE) wins and gains one new champion.\n");
		            printf("Player2 (FIGHTER) loses but with no penalty.\n");
		        }
		
		        else if(player2Level > player1Level)        //if player2 wins, player1 loses a champion
		        {
		            player1 = removeChampion(player1);
		            printf("Player 1(MAGE) loses one champion.\n");
		            printf("Player 2 (FIGHTER) wins but gains no rewards.\n");
		        }

		        else if(player1Level == player2Level)       //if its tie nothing happens
		        {
		            printf("TIE\n");
		        }
	        }  

	        else if(player2Role == 'S')     // if player2 is a SUPPORT
	        {
		        printf("Player 1 is a MAGE and Player 2 is a SUPPORT\n");
                if(player1Level > player2Level)     // if player1 wins gains champion and player2 loses 2 champions
		        {
		            player1 = addChampion(player1, createChampion());
		            player2 = removeChampion(player2);
		            player2 = removeChampion(player2);
		            printf("Player 1 (MAGE) wins and gains one new champion.\n");
		            printf("Player 2 (SUPPORT) loses two champions.\n");
		        }

		        else if(player2Level > player1Level) // if player2 wins gains 2 champions and player1 loses a champion
		        {
		            player1 = removeChampion(player1);
		            player2 = addChampion(player2, createChampion());
		            player2 = addChampion(player2, createChampion());
		            printf("Player 1 (MAGE) loses one champion.\n");
		            printf("Player 2(SUPPORT) wins and gains two new champions.\n");
		        }

		        else if(player1Level == player2Level)   //if tie nothing happens
		        {
		            printf("TIE");
		        }
	        }

	        else if(player2Role == 'T')     //if player 2 is TANK, player1 wins a champion and player2 loses a champion
	        {
		        printf("Player 1 is a MAGE and Player 2 is a TANK.\n");
		        player1 = addChampion(player1, createChampion());           
		        player2 = removeChampion(player2);
		        printf("Player 1 (MAGE) wins and gains one new champion.\n");
		        printf("Player 2 (TANK) loses one champion.\n");
	        }
	    }

	    else if(player1Role == 'F')     //if player1 is a FIGHTER
	    {
            if(player2Role == 'M')      //if player2 is MAGE
	        {
		        printf("Player 1 is a FIGHTER and Player 2 is a MAGE.\n");
		        if(player1Level > player2Level)     //if player1, player2 loses a champion
		        {
                    player2 = removeChampion(player2);
		            printf("Player 1 (FIGHTER) wins but gains no reward.\n");
		            printf("Player 2 (MAGE) loses one champion.\n");
		        }

		        else if(player2Level > player1Level)        //if player2 wins gains a champion
		        {
		            player2 = addChampion(player2, createChampion());
		            printf("Player 1 (FIGHTER) loses but with no penalty.\n");
		            printf("Player 2 (MAGE) wins and gain one new champion.\n");
		        }

		        else if(player1Level == player2Level)       //tie nothing happens
		        {
		            printf("TIE.\n");
		        }
	        }
	   
	        else if(player2Role == 'F') //if player2 is a FIGHTER, both players gain a champion
	        {
		        printf("Player 1 is a FIGHTER and Player 2 is a FIGHTER.\n");
		        player1 = addChampion(player1, createChampion());
		        player2 = addChampion(player2, createChampion());
		        printf("Both players gain one new champion.\n");
	        }

	        else if(player2Role == 'S')     //if player2 is SUPPORT
	        {
		        printf("Player 1 is FIGHTER and Player 2 is a SUPPORT.\n");
		        if(player1Level > player2Level)     //if player1 wins then player2 loses a champion
		        {
		            player2 = removeChampion(player2);
		            printf("Player 1 (FIGHTER) wins but gains no reward.\n");
		            printf("Player 2 (SUPPORT) loses one champion.\n");
		        }

		        else if(player2Level > player1Level)        //if player2 wins gains a champion
		        {
		            player2 = addChampion(player2, createChampion());
		            printf("Player 1 (FIGHTER) loses but with no penalty.\n");
		            printf("Player 2 (SUPPORT) wins and gains one new champion.\n");
		        }

		        else if(player1Level == player2Level)       //Tie nothing happens
		        {
		            printf("TIE.\n");
		        }
	        }

	        else if(player2Role == 'T')         //if player2 is a TANK player1 gains a champion
	        {
		        printf("Player 1 is a FIGHTER and Player 2 is a TANK.\n");
		        player1 = addChampion(player1, createChampion());
		        printf("Player 1 (FIGHTER) wins and gains one new champion.\n");
		        printf("Player 2 (TANK) loses but with no penalty.\n");
	        }
	    }

	    else if (player1Role == 'S')        //if player1 is a SUPPORT
        {
            if (player2Role == 'M')     //player2 is a MAGE
            {
                printf("Player 1 is a SUPPORT and Player 2 is a MAGE\n");
                if (player1Level > player2Level)  //if player1 wins gains 2 champions and player2 loses a champion
                {
                    player1 = addChampion(player1, createChampion());
                    player1 = addChampion(player1, createChampion());
                    player2 = removeChampion(player2);
                    printf("Player 1 (SUPPORT) wins and gains two new champions.\n");
                    printf("Player 2 (MAGE) loses one champion.\n");
                }
                else if (player2Level > player1Level)   //if player2 wins gains a champion and player1 loses two
                {
                    player1 = removeChampion(player1);
                    player1 = removeChampion(player1);
                    player2 = addChampion(player2, createChampion());
                    printf("Player 1 (SUPPORT) loses two champions.\n");
                    printf("Player 2 (MAGE) wins and gains one new champion.\n");
                }
                else if (player1Level == player2Level) //if tie nothing happens
                {
                    printf("TIE.\n");
                }
            }
  
            else if (player2Role == 'F')        //if player2 is a FIGHTER
            {
                printf("Player 1 is a SUPPORT and Player 2 is a FIGHTER\n");
                if (player1Level > player2Level)        //if player1 wins gains a champion
                {
                    player1 = addChampion(player1, createChampion());
                    printf("Player 1 (SUPPORT) wins and gains one new champion.\n");
                    printf("Player 2 (FIGHER) loses but with no penalty.\n");
                } 

                else if (player2Level > player1Level)  //if player2 wins, player1 loses a champion
                {
                    player1 = removeChampion(player1);
                    printf("Player 1 (SUPPORT) loses one champion.\n");
                    printf("Player 2 (FIGHTER) wins but gains no reward.\n");
                }
 
                else if (player1Level == player2Level)  //both tie nothing happens
                {
                    printf("TIE.\n");
                }
            }

            else if (player2Role == 'S')        //player2 is a SUPPORT, player1 gains champion and player2 loses a champion
            {
                printf("Player 1 is a SUPPORT and Player 2 is a SUPPORT\n");
                player1 = removeChampion(player1);
                player2 = removeChampion(player2);
                printf("Both players lose the next champion.\n");
            }

            else if (player2Role == 'T')        //if player2 is a TANK, player2 loses a champion
            {
                printf("Player 1 is a SUPPORT and Player 2 is a TANK\n");
                player2 = addChampion(player2, createChampion());
                printf("Player 1 (SUPPORT) loses but with no penalty.\n");
                printf("Player 2 (TANK) wins and gains one new champion.\n");
            }
        }

        else if (player1Role == 'T')        //player1 is a TANK
        {
            if (player2Role == 'M')     //player2 is a MAGE, player1 loses a champion and player2 gains a champion
            {
                printf("Player 1 is a TANK and Player 2 is a MAGE\n");
                player1 = removeChampion(player1);
                player2 = addChampion(player2, createChampion());
                printf("Player 1 (TANK) loses one champion.\n");
                printf("Player 2 (MAGE) wins and gains one new champion.\n");
            }
            else if (player2Role == 'F') //player2 is a FIGHTER and gains a champion
            {
                printf("Player 1 is a TANK and Player 2 is a FIGHTER\n");
                player2 = addChampion(player2, createChampion());
                printf("Player 1 (TANK) loses but with no penalty.\n");
                printf("Player 2 (FIGHTER) wins and gains one new champion.\n");
            }
            else if (player2Role == 'S')        //player2 is a SUPPORT
            {
                printf("Player 1 is a TANK and Player 2 is a SUPPORT\n");
                player1 = addChampion(player1, createChampion());
                printf("Player 1 (TANK) wins and gains one new champion.\n");
                printf("Player 2 (SUPPORT) loses but with no penalty.\n");
            }
            else if (player2Role == 'T')        //if player2 is a TANK then its a tie
            {
                printf("Player 1 is a TANK and Player 2 is a TANK\n");
                printf("TIE.\n");
            }
        }
       player1 = removeChampion(player1);       //removes the champions of player1
       player2 = removeChampion(player2);       //removes the champions of player2
       p1copy = player1;
       p2copy = player2;
       round++;                                 //increments the round
    }
    
    printf("\n============ GAME OVER  =============\n");
    printf("\n");
    printf("Player 1 ending champion list: ");
    printChampionList(player1);
    printf("Player 2 ending champion list: ");
    printChampionList(player2);
    if (player1 == NULL && player2 == NULL)                         //end of while loop both players are NULL then tie
    {
        printf("\nTIE -- both players ran out of champions.\n");
   }
   else if (player1 == NULL)                //if player1 is NULL then player2 wins
   {
      printf("\nPlayer 1 ran out of champions. Player 2 wins.\n");
   }
   else if (player2 == NULL)                //if player2 is NULL then player1 wins
   {
      printf("\nPlayer 2 ran out of champions. Player 1 wins.\n");
   }
   destroyChampionList(player1);            //removes all nodes from both players
   destroyChampionList(player2);

    return 0;
}