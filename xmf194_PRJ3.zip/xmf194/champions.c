#include "champions.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


Champion* createChampion(){
        Champion* champ = (Champion*)malloc(sizeof(Champion));

        int prob = rand()%4; //Random Number 0-3

        switch (prob){//switch to assign roles based on random number
            case 0://mage
                champ->role = M;
                champ->level = rand()%4+5; //5-8
                break;
            case 1://fighter
                champ->role = F;
                champ->level = rand()%4+1;//1-4
                break;
            case 2: //support
                champ->role = S;
                champ->level = rand()%4+3;//3-6
                break;
            case 3:
                //tank
                champ->role = T;
                champ->level = rand()%8+1;//1-8
                break;
            default:
                break;
        }
        return champ;
}

Champion* addChampion(Champion *head, Champion *c){
        Champion* current = head;
        Champion* prev = NULL;

//Traverse the linked list to find the correct position to insert the new champion node
        while((current!=NULL) && (current->level >= c->level))
        {
                prev = current;
                current = current->next;
        }

        if(prev == NULL)
        {
                c->next = head;
                head = c;
        }

        else{
                prev->next = c;
                c->next = current;
        }

        return head;
}

Champion* buildChampionList(int n)      //gets number for user to give both players their initial champions
{
        int i;
        Champion* head = NULL;

        for(i=0;i<n;i++)
        {
                head = addChampion(head, createChampion());
        }
        printf("\n");
        return head;
}

void printChampionList(Champion *head)          //prints champions
{
    Champion* current = head;

    while(current != NULL)//While in current list
    {
        printf("%c%d ",current->role,current->level);
        current = current->next;//Go to next champion
    }
   printf("\n");
}

Champion* removeChampion(Champion *head)
{
    Champion* copy = head;

    if(copy == NULL)
    {
        return NULL;    //return NULL if list is empty
    }

   head = head->next; // index of head + 1

   free(copy);  //Deallocates memeory for the "removed" node

    return head;
}

Champion* destroyChampionList(Champion *head)           //removes all nodes of the champions
{

    Champion* copy = head;

    while(copy != NULL)
    {
        Champion* removeNode = copy;
        copy = copy->next;
        free(removeNode);
      }
   return NULL;
}