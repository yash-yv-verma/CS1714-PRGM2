#ifndef CHAMPIONS_H
#define CHAMPIONS_H


typedef enum ChampionRole{M = 'M',F = 'F',S = 'S',T = 'T'} ChampionRole;        //lsit of roles

typedef struct Champion{//struct
    ChampionRole role;
    int level;
    struct Champion* next;
}Champion;


//function prototypes
Champion* createChampion();
Champion* addChampion(Champion*, Champion*);
Champion* buildChampionList(int);
void printChampionList(Champion*);
Champion* removeChampion(Champion*);
Champion* destroyChampionList(Champion*);

#endif