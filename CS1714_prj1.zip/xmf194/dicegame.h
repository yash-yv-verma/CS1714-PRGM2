#ifndef DICEGAME_H_//Start of the header file 
#define DICEGAME_H_

enum ROUNDTYPE { BONUS, DOUBLE, REGULAR };//This is the enum 

//All function prototypes in 
int getRandomNumber(int, int);
enum ROUNDTYPE getRoundType();
int getRoundPoints(enum ROUNDTYPE);
void printPlayerPoints(int, int);
void printRoundInfo(enum ROUNDTYPE, int, int);

#endif /*DICEGAME_H_*/ // End of header file